Domino Gateway for Irish Home Price Models

Models supported:
- irish_home_price_reg
- irish_home_price_clf

Launch command in Domino App:

uvicorn app.main:app --host 0.0.0.0 --port 8888

Environment variable:

MODEL_ROUTES_JSON={
 "irish_home_price_reg": {"url": "MODEL_ENDPOINT_URL", "token":"TOKEN"},
 "irish_home_price_clf": {"url": "MODEL_ENDPOINT_URL", "token":"TOKEN"}
}