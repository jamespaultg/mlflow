from pydantic import BaseModel

class IrishHomePriceInput(BaseModel):
    sale_year: int
    sale_month: int
    address: str
    county: str
    eircode: str | None = None