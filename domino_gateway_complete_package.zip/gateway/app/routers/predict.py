import os, json, uuid, time, requests
from fastapi import APIRouter, Header, HTTPException
from ..schemas import GatewayRequest, GatewayResponse
from ..model_validations import IrishHomePriceInput

router = APIRouter()

def load_routes():
    raw = os.getenv("MODEL_ROUTES_JSON","{}")
    return json.loads(raw)

@router.post("/predict", response_model=GatewayResponse)
def predict(req: GatewayRequest, x_correlation_id: str | None = Header(default=None)):

    correlation_id = x_correlation_id or str(uuid.uuid4())
    start = time.perf_counter()

    routes = load_routes()

    if req.model_key not in routes:
        raise HTTPException(status_code=400, detail="Unknown model_key")

    for r in req.inputs:
        IrishHomePriceInput(**r)

    route = routes[req.model_key]

    headers = {"Content-Type":"application/json"}
    if route.get("token"):
        headers["Authorization"] = f"Bearer {route['token']}"

    resp = requests.post(route["url"], json={"inputs":req.inputs}, headers=headers)

    latency = (time.perf_counter()-start)*1000

    if resp.status_code!=200:
        raise HTTPException(status_code=502, detail="Model endpoint error")

    return {
        "correlation_id": correlation_id,
        "model_key": req.model_key,
        "latency_ms": latency,
        "result": resp.json()
    }