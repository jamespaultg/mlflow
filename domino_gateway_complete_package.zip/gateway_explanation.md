Gateway Overview

Client calls ONE endpoint:

POST /predict

Gateway responsibilities:
- Validate request schema
- Generate correlation ID
- Route to appropriate model endpoint
- Add latency metadata
- Return standardized response

Routing controlled by MODEL_ROUTES_JSON.