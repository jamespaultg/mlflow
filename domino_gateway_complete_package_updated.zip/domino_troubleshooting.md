Domino Gateway Troubleshooting

1. 404 Unauthorized
Possible causes:
- Model endpoint requires Bearer token
- Wrong endpoint URL
- Token missing in Authorization header

Solution:
Check endpoint security settings and ensure header:

Authorization: Bearer <MODEL_ACCESS_TOKEN>

2. Model endpoint returns error
Check Domino model logs.

3. Gateway not starting
Ensure launch command:

uvicorn app.main:app --host 0.0.0.0 --port 8888