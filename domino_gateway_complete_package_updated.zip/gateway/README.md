Domino Gateway for Irish Home Price Models

Models supported:
- irish_home_price_reg
- irish_home_price_clf

Launch command in Domino App:

uvicorn app.main:app --host 0.0.0.0 --port 8888

Environment variable:

MODEL_ROUTES_JSON={
 "irish_home_price_reg": {"url": "MODEL_ENDPOINT_URL", "token":"TOKEN"},
 "irish_home_price_clf": {"url": "MODEL_ENDPOINT_URL", "token":"TOKEN"}
}

## Request and Response Contracts

### Request (GatewayRequest)

```json
{
  "model_key": "irish_home_price_reg",
  "inputs": [
    {
      "county": "Dublin",
      "town": "Tallaght",
      "property_type": "Semi-Detached",
      "bedrooms": 3,
      "bathrooms": 2,
      "floor_area_sqm": 110.0,
      "year_built": 2005,
      "sale_date": "2024-03-15",
      "latitude": 53.2879,
      "longitude": -6.3550
    }
  ]
}
```

- `model_key` must match a key in `MODEL_ROUTES_JSON`.
- Each element in `inputs` is validated against `IrishHomePriceInput`.

### Response (GatewayResponse)

```json
{
  "correlation_id": "uuid",
  "model_key": "irish_home_price_reg",
  "latency_ms": 12.3,
  "result": { "your_model_endpoint_response": "..." }
}
```

## Feature Creation Component (Instance 1)

The gateway implements the **Feature Creation Component** required by the assessment:

1. Validates raw inputs using `IrishHomePriceInput`.
2. Transforms them into engineered features via `feature_creation.create_features`.
3. Forwards the resulting feature dictionaries to the configured model endpoint.

Engineered features include:

- `sale_year`, `sale_month`, `sale_quarter`, `is_post_2020`
- `room_count`, `is_large_property`, `property_age`, `age_bucket`
- Original numeric and categorical fields (county, town, property_type, bedrooms, bathrooms, floor_area_sqm, year_built, latitude, longitude)

The downstream Domino model app (Instance 2) loads the model from the Domino Model Registry and performs any additional encoding required for inference.
