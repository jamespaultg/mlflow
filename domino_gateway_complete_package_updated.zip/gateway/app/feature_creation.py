from __future__ import annotations

from datetime import date
from typing import Any, Dict, List

from .model_validations import IrishHomePriceInput


LARGE_PROPERTY_THRESHOLD_SQM = 120.0


def _age_bucket(property_age: int) -> str:
    if property_age <= 0:
        return "New"
    if property_age <= 10:
        return "0-10"
    if property_age <= 30:
        return "10-30"
    return "30+"


def create_features(records: List[IrishHomePriceInput]) -> List[Dict[str, Any]]:
    """Create model-ready feature dictionaries from validated raw inputs.

    This is the "Feature Creation Component" required by the assessment.
    It is invoked by the gateway (Instance 1) before forwarding the request
    to the model endpoints (Instance 2).

    The feature set includes:
    - Date-based features: sale_year, sale_month, sale_quarter, is_post_2020
    - Property features: room_count, is_large_property, property_age, age_bucket
    - Original numeric features: bedrooms, bathrooms, floor_area_sqm, latitude, longitude
    - Categorical/location features: county, town, property_type

    The downstream model service can perform any additional encoding that is
    needed (e.g. one-hot/target encoding for categoricals).
    """
    features: List[Dict[str, Any]] = []

    for rec in records:
        sale_dt: date = rec.sale_date
        sale_year = sale_dt.year
        sale_month = sale_dt.month
        sale_quarter = (sale_month - 1) // 3 + 1
        is_post_2020 = int(sale_year >= 2020)

        room_count = rec.bedrooms + rec.bathrooms
        is_large_property = int(rec.floor_area_sqm > LARGE_PROPERTY_THRESHOLD_SQM)

        property_age = max(sale_year - rec.year_built, 0)
        age_bucket = _age_bucket(property_age)

        record_features: Dict[str, Any] = {
            # Categorical/location information
            "county": rec.county,
            "town": rec.town,
            "property_type": rec.property_type,
            # Raw numeric fields
            "bedrooms": rec.bedrooms,
            "bathrooms": rec.bathrooms,
            "floor_area_sqm": rec.floor_area_sqm,
            "year_built": rec.year_built,
            "latitude": rec.latitude,
            "longitude": rec.longitude,
            # Engineered date features
            "sale_year": sale_year,
            "sale_month": sale_month,
            "sale_quarter": sale_quarter,
            "is_post_2020": is_post_2020,
            # Engineered property features
            "room_count": room_count,
            "is_large_property": is_large_property,
            "property_age": property_age,
            "age_bucket": age_bucket,
        }

        features.append(record_features)

    return features
