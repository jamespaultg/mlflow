from fastapi import FastAPI
from .routers.predict import router

app = FastAPI(title="Irish Home Price Gateway")

@app.get("/health")
def health():
    return {"status":"ok"}

app.include_router(router)