from datetime import date
from pydantic import BaseModel, Field


class IrishHomePriceInput(BaseModel):
    """Validated raw payload for Irish home price inference.

    This mirrors the JSON payload example in the assessment document.
    Feature engineering is applied on top of this schema in the
    feature_creation module.
    """

    county: str = Field(..., description="County name, e.g. 'Dublin'")
    town: str = Field(..., description="Town name, e.g. 'Tallaght'")
    property_type: str = Field(..., description="Property type, e.g. 'Semi-Detached'")
    bedrooms: int = Field(..., ge=0)
    bathrooms: int = Field(..., ge=0)
    floor_area_sqm: float = Field(..., gt=0)
    year_built: int = Field(..., ge=1800, description="4-digit construction year")
    sale_date: date = Field(..., description="Sale date in ISO format, e.g. '2024-03-15'")
    latitude: float
    longitude: float
