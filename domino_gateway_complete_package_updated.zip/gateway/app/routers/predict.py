import json
import os
import time
import uuid
from typing import Any, Dict, List

import requests
from fastapi import APIRouter, Header, HTTPException, status
from pydantic import ValidationError

from ..feature_creation import create_features
from ..model_validations import IrishHomePriceInput
from ..schemas import GatewayRequest, GatewayResponse


router = APIRouter()


def _load_routes() -> Dict[str, Dict[str, Any]]:
    """Load and validate MODEL_ROUTES_JSON configuration.

    Expected format:
    {
      "irish_home_price_reg": {"url": "...", "token": "..."},
      "irish_home_price_clf": {"url": "...", "token": "..."}
    }
    """
    raw = os.getenv("MODEL_ROUTES_JSON")
    if not raw:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="MODEL_ROUTES_JSON environment variable is not set.",
        )

    try:
        routes = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"MODEL_ROUTES_JSON is not valid JSON: {exc.msg}",
        ) from exc

    if not isinstance(routes, dict):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="MODEL_ROUTES_JSON must be a JSON object mapping model_key to route config.",
        )

    return routes


def _get_route(model_key: str) -> Dict[str, Any]:
    routes = _load_routes()
    try:
        route = routes[model_key]
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown model_key '{model_key}'.",
        )
    if "url" not in route:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Route configuration for model_key '{model_key}' is missing 'url'.",
        )
    return route


def _validate_inputs(raw_inputs: List[Dict[str, Any]]) -> List[IrishHomePriceInput]:
    validated: List[IrishHomePriceInput] = []
    errors: List[Dict[str, Any]] = []

    for idx, record in enumerate(raw_inputs):
        try:
            validated.append(IrishHomePriceInput(**record))
        except ValidationError as exc:
            errors.append({"index": idx, "errors": exc.errors()})

    if errors:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": "Invalid input payload.", "items": errors},
        )

    return validated


@router.post("/predict", response_model=GatewayResponse)
def predict(
    req: GatewayRequest,
    x_correlation_id: str | None = Header(default=None),
):
    """Gateway prediction endpoint.

    Responsibilities (Instance 1 in the assessment):
    - Validate raw JSON payload against the expected schema.
    - Apply feature creation to produce model-ready inputs.
    - Forward the request to the appropriate model endpoint based on model_key.
    - Return a standardised response with correlation_id and latency.
    """

    correlation_id = x_correlation_id or str(uuid.uuid4())
    start = time.perf_counter()

    # 1) Validate and parse raw inputs
    validated_inputs = _validate_inputs(req.inputs)

    # 2) Feature creation component
    features = create_features(validated_inputs)

    # 3) Route lookup
    route = _get_route(req.model_key)

    headers = {"X-Correlation-Id": correlation_id}
    token = route.get("token")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    # 4) Call downstream model endpoint
    try:
        resp = requests.post(
            route["url"],
            json={"inputs": features},
            headers=headers,
            timeout=10,
        )
    except requests.RequestException:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Error calling model endpoint.",
        )

    latency_ms = (time.perf_counter() - start) * 1000.0

    if resp.status_code != status.HTTP_200_OK:
        # Surface status code while keeping body generic for safety.
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Model endpoint error (status_code={resp.status_code}).",
        )

    return {
        "correlation_id": correlation_id,
        "model_key": req.model_key,
        "latency_ms": latency_ms,
        "result": resp.json(),
    }
