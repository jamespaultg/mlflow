from typing import Any, Dict, List
from pydantic import BaseModel

class GatewayRequest(BaseModel):
    model_key: str
    inputs: List[Dict[str,Any]]

class GatewayResponse(BaseModel):
    correlation_id: str
    model_key: str
    latency_ms: float
    result: Dict[str,Any]