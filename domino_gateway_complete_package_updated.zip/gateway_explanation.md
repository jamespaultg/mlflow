Gateway Overview

Client calls ONE endpoint:

POST /predict

Gateway responsibilities:
- Validate raw request payload against the Irish home price schema
- Run the **feature creation component** to compute engineered features
- Generate / propagate correlation ID
- Route to appropriate model endpoint
- Add latency metadata
- Return standardized response

Routing controlled by MODEL_ROUTES_JSON.